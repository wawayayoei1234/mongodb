﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using demomvc.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;

namespace demomvc.Controllers {
    public class HomeController : Controller {
        private readonly ILogger<HomeController> _logger;

        public class Student {
            public string Id { get; set; }
            public string Name { get; set; }
            public bool IsMale { get; set; }
        }
        public HomeController (ILogger<HomeController> logger) {

            //var dbClient = new MongoClient ("");
            //var database = dbClient.GetDatabase ("YOUR_DB_NAME");
            //var collection = database.GetCollection<Student> ("student");

            // CREATE
            // var newStd = new Student {
            //     Id = "S01",
            //     Name = "TheS"
            // };
            // collection.InsertOne (newStd);

            // FIND (collection: student)
            // |Id |Name|IsMale|
            // -----------------
            // |S01|Boy |true  |
            // |S02|Girl|false |
            // |S03|Girl|false |
            // var data = collection.Find (it => it.IsMale == false).ToList ();
            // foreach (var item in data) {
            //     System.Console.WriteLine (item.Id + item.Name + item.IsMale);
            // }

            // var data2 = collection.Find (it => it.IsMale == true).ToList ();
            // var first = data2.FirstOrDefault ();
            // System.Console.WriteLine (first.Id + first.Name + first.IsMale);

            // DELETE (collection: student)
            // |Id |Name|IsMale|
            // -----------------
            // |S01|Boy |true  |
            // |S02|Girl|false |
            // |S03|Girl|false |

            //collection.DeleteOne (it => it.IsMale == false);
            // |S01|Boy |true  |
            // |S03|Girl|false |

            // collection.DeleteMany (it => it.IsMale == false);
            // |S01|Boy |true  |

            // EDIT (collection: student)
            // |Id |Name|IsMale|
            // -----------------
            // |S01|Boy |true  |
            // |S02|Girl|false |
            // |S03|Girl|false |
            // var def = Builders<Student>.Update.Set (it => it.Name, "X");
            // collection.UpdateOne (it => it.Id == "S01", def);
            // |S01|Boy |true  |
            // |S02|Girl|false |
            // |S03|Girl|false |
        }

        public IActionResult Index () {
            return View ();
        }

        public IActionResult Privacy () {
            // get teachers from the database
            var teachers = new List<Teacher>
            {
                new Teacher{ Id = 1, Name = "A", Age = 1},
                new Teacher{ Id = 2, Name = "B", Age = 2},
                new Teacher{ Id = 3, Name = "C", Age = 3},
                new Teacher{ Id = 4, Name = "D", Age = 4},
                new Teacher{ Id = 5, Name = "E", Age = 5},
            };
            return View (teachers);
        }




        [ResponseCache (Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error () {
            return View (new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}