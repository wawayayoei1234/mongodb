﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using demomvc.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;

namespace demomvc.Controllers
{
    public class TeacherController : Controller
    {
        static List<Teacher> teachers = new List<Teacher>
        {
            new Teacher{ Id = 1, Name = "A", Age = 1, ProfileImageUrl = "https://image.flaticon.com/icons/png/512/16/16363.png"},
            new Teacher{ Id = 2, Name = "B", Age = 2, ProfileImageUrl = "https://image.flaticon.com/icons/png/512/16/16363.png"},
            new Teacher{ Id = 3, Name = "C", Age = 3, ProfileImageUrl = "https://image.flaticon.com/icons/png/512/16/16363.png"},
            new Teacher{ Id = 4, Name = "D", Age = 4, ProfileImageUrl = "https://image.flaticon.com/icons/png/512/16/16363.png"},
            new Teacher{ Id = 5, Name = "E", Age = 5, ProfileImageUrl = "https://image.flaticon.com/icons/png/512/16/16363.png"},
        };
        private IMongoCollection<Teacher> teacherCollection;

        public TeacherController()
        {
            //var dbClient = new MongoClient("");
            //var database = dbClient.GetDatabase("YOUR_DB_NAME");
            //teacherCollection = database.GetCollection<Teacher>("teacher");
        }

        public IActionResult Index()
        {
            //var teachers = teacherCollection.Find(it => true).ToList();

            return View(teachers);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Teacher data)
        {
            //teacherCollection.InsertOne(data);
            teachers.Add(data);
            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            //var selected = teacherCollection.Find(it => it.Id == id).ToList().FirstOrDefault();

            var selected = teachers.FirstOrDefault(it => it.Id == id);

            return View(selected);
        }

        [HttpPost]
        public IActionResult Delete(Teacher data)
        {
            //teacherCollection.DeleteOne(it => it.Id == data.Id);

            var selected = teachers.FirstOrDefault(it => it.Id == data.Id);
            teachers.Remove(selected);

            return RedirectToAction("Index");
        }

        public IActionResult Details(int id)
        {
            //var selected = teacherCollection.Find(it => it.Id == id).ToList().FirstOrDefault();

            var selected = teachers.FirstOrDefault(it => it.Id == id);

            return View(selected);
        }

        public IActionResult Edit(int id)
        {
            //var selected = teacherCollection.Find(it => it.Id == id).ToList().FirstOrDefault();

            var selected = teachers.FirstOrDefault(it => it.Id == id);

            return View(selected);
        }
    }
}